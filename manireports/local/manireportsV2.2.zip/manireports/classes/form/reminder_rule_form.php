<?php
namespace local_manireports\form;

defined('MOODLE_INTERNAL') || die();

require_once($CFG->libdir . '/formslib.php');

class reminder_rule_form extends \moodleform {

    public function definition() {
        global $DB;

        $mform = $this->_form;

        // General Section
        $mform->addElement('html', '<h4 class="text-xl font-bold text-gray-800 dark:text-white mb-4 mt-2 border-b border-gray-200 dark:border-gray-700 pb-2">' . get_string('general', 'form') . '</h4>');

        // Hidden ID for editing
        $mform->addElement('hidden', 'id');
        $mform->setType('id', PARAM_INT);

        // Rule Name
        $mform->addElement('text', 'name', get_string('rulename', 'local_manireports'));
        $mform->setType('name', PARAM_TEXT);
        $mform->addRule('name', null, 'required', null, 'client');
        $mform->addElement('static', 'name_help', '', '<div class="text-sm text-gray-600 dark:text-gray-600 mt-1">' . get_string('rulename_help', 'local_manireports') . '</div>');

        // Fetch rule data if editing
        $rule_id = $this->_customdata['id'] ?? 0;
        $db_rule = null;
        if ($rule_id) {
            $db_rule = $DB->get_record('manireports_rem_rule', ['id' => $rule_id]);
            if ($db_rule) {
                error_log("Form Definition: Loaded rule ID $rule_id. Company: {$db_rule->companyid}, Course: {$db_rule->courseid}, Activity: {$db_rule->activityid}");
            } else {
                error_log("Form Definition: Failed to load rule ID $rule_id");
            }
        }

        // Company Dropdown (REQUIRED - shows ALL companies)
        $companies = $DB->get_records_menu('company', null, 'name ASC', 'id, name');
        $companies = ['' => get_string('selectcompany', 'local_manireports')] + $companies;
        $mform->addElement('select', 'companyid', get_string('company', 'local_manireports'), $companies);
        $mform->addRule('companyid', null, 'required', null, 'client');
        $mform->addElement('static', 'companyid_help', '', '<div class="text-sm text-gray-600 dark:text-gray-600 mt-1">' . get_string('company_help', 'local_manireports') . '</div>');

        // Course Dropdown (filtered by company via AJAX)
        // Populate options server-side if companyid is submitted (for validation)
        $course_options = ['' => get_string('selectcompanyfirst', 'local_manireports')];
        $companyid = optional_param('companyid', 0, PARAM_INT);
        
        // Use DB value if not overridden by param
        if (!$companyid && $db_rule) {
            $companyid = $db_rule->companyid;
        }

        if ($companyid) {
            error_log("Form Definition: Found companyid $companyid. Fetching courses...");
            $courses = $DB->get_records_sql_menu("
                SELECT c.id, c.fullname
                FROM {course} c
                JOIN {company_course} cc ON cc.courseid = c.id
                WHERE cc.companyid = :companyid AND c.id != :siteid
                ORDER BY c.fullname", ['companyid' => $companyid, 'siteid' => SITEID]);
            if ($courses) {
                error_log("Form Definition: Found " . count($courses) . " courses.");
                $course_options = ['' => get_string('selectcourse', 'local_manireports')] + $courses;
            } else {
                error_log("Form Definition: No courses found for company $companyid.");
                $course_options = ['' => 'No courses found'];
            }
        } else {
            error_log("Form Definition: No companyid found.");
        }

        $mform->addElement('select', 'courseid', get_string('courseid', 'local_manireports'), $course_options);
        $mform->addRule('courseid', null, 'required', null, 'client');
        $mform->addElement('static', 'courseid_help', '', '<div class="text-sm text-gray-600 dark:text-gray-600 mt-1">' . get_string('courseid_help', 'local_manireports') . '</div>');


        // Trigger Settings
        $mform->addElement('html', '<h4 class="text-xl font-bold text-gray-800 dark:text-white mb-4 mt-6 border-b border-gray-200 dark:border-gray-700 pb-2">Trigger Settings</h4>');

        // Trigger Type
        $triggers = [
            'enrol' => get_string('triggertype_enrol', 'local_manireports'),
            'start_date' => get_string('triggertype_startdate', 'local_manireports'),
            'incomplete_after' => get_string('triggertype_incomplete', 'local_manireports'),
            'license_expiry' => get_string('triggertype_license_expiry', 'local_manireports'),
            'license_utilization' => get_string('triggertype_license_utilization', 'local_manireports'),
            'custom' => get_string('triggertype_custom', 'local_manireports'),
        ];
        $mform->addElement('select', 'trigger_type', get_string('triggertype', 'local_manireports'), $triggers);
        $mform->addElement('static', 'trigger_type_help', '', '<div class="text-sm text-gray-600 dark:text-gray-600 mt-1">' . get_string('triggertype_help', 'local_manireports') . '</div>');

        // Trigger Value (Number + Unit Dropdown)
        $mform->addElement('html', '<div class="fitem"><div class="fitemtitle"><label>' . get_string('triggervalue', 'local_manireports') . ' <span class="text-danger">*</span></label></div><div class="felement" style="display: flex; gap: 8px;">');
        
        $mform->addElement('text', 'trigger_value', '', ['size' => 10, 'style' => 'margin: 0;']);
        $mform->setType('trigger_value', PARAM_INT);
        $mform->setDefault('trigger_value', 7);
        
        $units = [
            'minutes' => get_string('minutes'),
            'hours' => get_string('hours'),
            'days' => get_string('days'),
            'weeks' => get_string('weeks'),
            'percent' => '%'
        ];
        $mform->addElement('select', 'trigger_unit', '', $units, ['style' => 'margin: 0; min-width: 120px;']);
        $mform->setDefault('trigger_unit', 'days');
        
        $mform->addElement('html', '</div></div>');
        $mform->addElement('static', 'trigger_value_help', '', '<div class="text-sm text-gray-600 dark:text-gray-600 mt-1">' . get_string('triggervalue_help', 'local_manireports') . '</div>');

        
        // Target Activity (MANDATORY)
        // Populate options server-side if courseid is submitted
        $activity_options = ['' => get_string('selectcoursefirst', 'local_manireports')];
        $courseid = optional_param('courseid', 0, PARAM_INT);
        
        // Use DB value if not overridden by param
        if (!$courseid && $db_rule) {
            $courseid = $db_rule->courseid;
        }

        if ($courseid) {
            $modinfo = get_fast_modinfo($courseid);
            $activities = [];
            foreach ($modinfo->get_cms() as $cm) {
                if ($cm->completion != COMPLETION_TRACKING_NONE && !$cm->deletioninprogress) {
                    $modname = get_string('modulename', $cm->modname);
                    $activities[$cm->id] = format_string($cm->name) . ' (' . $modname . ')';
                }
            }
            if ($activities) {
                $activity_options = ['-1' => 'Course Completion'] + $activities;
            } else {
                $activity_options = ['-1' => 'Course Completion'];
            }
        }

        $mform->addElement('select', 'activityid', get_string('targetactivity', 'local_manireports'), $activity_options);
        $mform->addRule('activityid', null, 'required', null, 'client');
        $mform->addElement('static', 'activityid_help', '', '<div class="text-sm text-gray-600 dark:text-gray-600 mt-1">' . get_string('targetactivity_help', 'local_manireports') . '</div>');

        // Schedule Settings
        $mform->addElement('html', '<h4 class="text-xl font-bold text-gray-800 dark:text-white mb-4 mt-6 border-b border-gray-200 dark:border-gray-700 pb-2">Schedule Settings</h4>');

        // Email Delay
        $mform->addElement('html', '<div class="fitem"><div class="fitemtitle"><label>' . get_string('emaildelay', 'local_manireports') . '</label></div><div class="felement" style="display: flex; gap: 8px;">');
        
        $mform->addElement('text', 'emaildelay_value', '', ['size' => 10, 'style' => 'margin: 0;']);
        $mform->setType('emaildelay_value', PARAM_INT);
        $mform->setDefault('emaildelay_value', 1);
        
        $delay_units = [
            'minutes' => get_string('minutes'),
            'hours' => get_string('hours'),
            'days' => get_string('days'),
            'weeks' => get_string('weeks')
        ];
        $mform->addElement('select', 'emaildelay_unit', '', $delay_units, ['style' => 'margin: 0; min-width: 120px;']);
        $mform->setDefault('emaildelay_unit', 'days');
        
        $mform->addElement('html', '</div></div>');
        $mform->addElement('static', 'emaildelay_help', '', '<div class="text-sm text-gray-600 dark:text-gray-600 mt-1">' . get_string('emaildelay_help', 'local_manireports') . '</div>');

        // Reminder Count
        $mform->addElement('text', 'remindercount', get_string('remindercount', 'local_manireports'));
        $mform->setType('remindercount', PARAM_INT);
        $mform->setDefault('remindercount', 1);
        $mform->addElement('static', 'remindercount_help', '', '<div class="text-sm text-gray-600 dark:text-gray-600 mt-1">' . get_string('remindercount_help', 'local_manireports') . '</div>');

        // Recipient Settings
        $mform->addElement('html', '<h4 class="text-xl font-bold text-gray-800 dark:text-white mb-4 mt-6 border-b border-gray-200 dark:border-gray-700 pb-2">Recipient Settings</h4>');

        // Send to User
        $mform->addElement('checkbox', 'send_to_user', get_string('sendtousers', 'local_manireports'));
        $mform->setDefault('send_to_user', 1);
        $mform->addElement('static', 'send_to_user_help', '', '<div class="text-sm text-gray-600 dark:text-gray-600 mt-1">' . get_string('sendtousers_help', 'local_manireports') . '</div>');

        // Send to Managers
        $mform->addElement('checkbox', 'send_to_managers', get_string('sendtomanagers', 'local_manireports'));
        $mform->setDefault('send_to_managers', 0);
        $mform->addElement('static', 'send_to_managers_help', '', '<div class="text-sm text-gray-600 dark:text-gray-600 mt-1">' . get_string('sendtomanagers_help', 'local_manireports') . '</div>');

        // Third Party Emails
        $mform->addElement('textarea', 'thirdparty_emails', get_string('thirdpartyemails', 'local_manireports'), 'rows="3" cols="50"');
        $mform->setType('thirdparty_emails', PARAM_TEXT);
        $mform->addElement('static', 'thirdparty_emails_help', '', '<div class="text-sm text-gray-600 dark:text-gray-600 mt-1">' . get_string('thirdpartyemails_help', 'local_manireports') . '</div>');

        // CC Emails
        $mform->addElement('textarea', 'cc_emails', get_string('cc_emails', 'local_manireports'), 'rows="3" cols="50"');
        $mform->setType('cc_emails', PARAM_TEXT);
        $mform->addElement('static', 'cc_emails_help', '', '<div class="text-sm text-gray-600 dark:text-gray-600 mt-1">' . get_string('cc_emails_help', 'local_manireports') . '</div>');

        // Content Settings
        $mform->addElement('html', '<h4 class="text-xl font-bold text-gray-800 dark:text-white mb-4 mt-6 border-b border-gray-200 dark:border-gray-700 pb-2">Content Settings</h4>');

        // Template Dropdown
        $templates = $DB->get_records_menu('manireports_rem_tmpl', ['enabled' => 1], 'name ASC', 'id, name');
        if (empty($templates)) {
            $templates = [0 => get_string('notemplates', 'local_manireports')];
        }
        $mform->addElement('select', 'templateid', get_string('templateid', 'local_manireports'), $templates);
        $mform->addRule('templateid', null, 'required', null, 'client');
        $mform->addElement('static', 'templateid_help', '', '<div class="text-sm text-gray-600 dark:text-gray-600 mt-1">' . get_string('templateid_help', 'local_manireports') . '</div>');

        // Enabled
        $mform->addElement('selectyesno', 'enabled', get_string('enabled', 'local_manireports'));
        $mform->setDefault('enabled', 1);

        $this->add_action_buttons();

        // Add inline JavaScript for dynamic field handling
        $js = "
        <script>
        jQuery(document).ready(function($) {
            // Cascading dropdowns for Company -> Course -> Activity
            $('#id_companyid').change(function() {
                var companyid = $(this).val();
                console.log('Company changed:', companyid);
                
                if (!companyid) {
                    $('#id_courseid').html('<option value=\"\">Select company first</option>');
                    $('#id_activityid').html('<option value=\"\">Select course first</option>');
                    return;
                }
                
                console.log('Loading courses for company:', companyid);
                
                $.ajax({
                    url: M.cfg.wwwroot + '/local/manireports/ajax/get_company_courses.php',
                    data: { companyid: companyid, sesskey: M.cfg.sesskey },
                    dataType: 'html',
                    success: function(response) {
                        console.log('Courses loaded');
                        $('#id_courseid').html(response);
                        $('#id_activityid').html('<option value=\"\">Select course first</option>');
                    },
                    error: function(xhr, status, error) {
                        console.error('AJAX Error loading courses:', status, error);
                        $('#id_courseid').html('<option value=\"\">Error loading courses</option>');
                    }
                });
            });
            
            $('#id_courseid').change(function() {
                var courseid = $(this).val();
                console.log('Course changed:', courseid);
                
                if (!courseid || courseid == '0' || courseid == '') {
                    $('#id_activityid').html('<option value=\"\">Select course first</option>');
                    return;
                }
                
                console.log('Loading activities for course:', courseid);
                
                $.ajax({
                    url: M.cfg.wwwroot + '/local/manireports/ajax/get_course_activities.php',
                    data: { courseid: courseid, sesskey: M.cfg.sesskey },
                    dataType: 'html',
                    success: function(response) {
                        console.log('Activities loaded');
                        var options = '<option value=\"-1\">Course Completion</option>';
                        options += response;
                        $('#id_activityid').html(options);
                    },
                    error: function(xhr, status, error) {
                        console.error('AJAX Error loading activities:', status, error);
                        $('#id_activityid').html('<option value=\"\">Error loading activities</option>');
                    }
                });
            });
            
            function updateFormFields() {
                var trigger = $('#id_trigger_type').val();
                var isLicense = (trigger === 'license_expiry' || trigger === 'license_utilization');
                
                if (isLicense) {
                    // Show Course (Modified: User requested to filter by course)
                    $('#fitem_id_courseid').show();
                    $('#id_courseid').prop('disabled', false);
                    
                    // Hide Activity (License triggers don't need specific activities like quizzes)
                    $('#fitem_id_activityid').hide();
                    
                    // Hide Send to User/Manager (License triggers go to specific recipients)
                    $('#fitem_id_send_to_user').hide();
                    $('#fitem_id_send_to_managers').hide();
                    
                    // Show CC
                    $('#fitem_id_cc_emails').show();
                    
                    // Update Labels
                    $('label[for=\"id_thirdparty_emails\"]').text('" . get_string('thirdpartyemails', 'local_manireports') . "');
                    
                    if (trigger === 'license_expiry') {
                        $('label[for=\"id_trigger_value\"]').text('" . get_string('trigger_days_expiry', 'local_manireports') . "');
                        // Enable time units, disable percent
                        $('#id_trigger_unit option[value=\"minutes\"]').prop('disabled', false);
                        $('#id_trigger_unit option[value=\"hours\"]').prop('disabled', false);
                        $('#id_trigger_unit option[value=\"days\"]').prop('disabled', false);
                        $('#id_trigger_unit option[value=\"weeks\"]').prop('disabled', false);
                        $('#id_trigger_unit option[value=\"percent\"]').prop('disabled', true);
                        if ($('#id_trigger_unit').val() === 'percent') {
                            $('#id_trigger_unit').val('days');
                        }
                    } else {
                        $('label[for=\"id_trigger_value\"]').text('" . get_string('trigger_utilization', 'local_manireports') . "');
                        // Disable time units, enable percent
                        $('#id_trigger_unit option[value=\"minutes\"]').prop('disabled', true);
                        $('#id_trigger_unit option[value=\"hours\"]').prop('disabled', true);
                        $('#id_trigger_unit option[value=\"days\"]').prop('disabled', true);
                        $('#id_trigger_unit option[value=\"weeks\"]').prop('disabled', true);
                        $('#id_trigger_unit option[value=\"percent\"]').prop('disabled', false);
                        $('#id_trigger_unit').val('percent');
                    }
                } else {
                    // Show Course, Activity, Send to User, Send to Manager
                    $('#fitem_id_courseid').show();
                    $('#id_courseid').prop('disabled', false); // Ensure enabled
                    
                    $('#fitem_id_activityid').show();
                    $('#id_activityid').prop('disabled', false); // Ensure enabled
                    
                    $('#fitem_id_send_to_user').show();
                    $('#fitem_id_send_to_managers').show();
                    
                    // Hide CC
                    $('#fitem_id_cc_emails').hide();
                    
                    // Revert Labels
                    $('label[for=\"id_thirdparty_emails\"]').text('" . get_string('thirdpartyemails', 'local_manireports') . "');
                    $('label[for=\"id_trigger_value\"]').text('" . get_string('triggervalue', 'local_manireports') . "');
                    
                    // Enable time units, disable percent
                    $('#id_trigger_unit option[value=\"minutes\"]').prop('disabled', false);
                    $('#id_trigger_unit option[value=\"hours\"]').prop('disabled', false);
                    $('#id_trigger_unit option[value=\"days\"]').prop('disabled', false);
                    $('#id_trigger_unit option[value=\"weeks\"]').prop('disabled', false);
                    $('#id_trigger_unit option[value=\"percent\"]').prop('disabled', true);
                    if ($('#id_trigger_unit').val() === 'percent') {
                        $('#id_trigger_unit').val('days');
                    }
                }
            }
            // Run on load and change
            $('#id_trigger_type').change(updateFormFields);
            updateFormFields();

            // Force selection if values exist (Fallback for pre-selection issues)
            var initialCourseId = '" . $courseid . "';
            var initialActivityId = '" . (isset($rule->activityid) ? $rule->activityid : '') . "';
            
            console.log('Debug Pre-selection:', {
                initialCourseId: initialCourseId,
                initialActivityId: initialActivityId,
                courseOptionsCount: $('#id_courseid option').length,
                courseOptionExists: $('#id_courseid option[value=\"' + initialCourseId + '\"]').length > 0
            });

            if (initialCourseId && $('#id_courseid option[value=\"' + initialCourseId + '\"]').length > 0) {
                console.log('Forcing course selection to:', initialCourseId);
                $('#id_courseid').val(initialCourseId);
            } else {
                console.warn('Could not force course selection. ID:', initialCourseId);
            }
            
            if (initialActivityId && $('#id_activityid option[value=\"' + initialActivityId + '\"]').length > 0) {
                console.log('Forcing activity selection to:', initialActivityId);
                $('#id_activityid').val(initialActivityId);
            }
        });
        </script>
        ";
        $mform->addElement('html', $js);
    }

    public function validation($data, $files) {
        $errors = parent::validation($data, $files);

        // Validate rule name
        if (empty(trim($data['name']))) {
            $errors['name'] = get_string('required');
        }

        // Validate reminder count (1-5)
        if (isset($data['remindercount'])) {
            if ($data['remindercount'] < 1 || $data['remindercount'] > 5) {
                $errors['remindercount'] = 'Number of reminders must be between 1 and 5';
            }
        }

        // Validate trigger days
        if (isset($data['trigger_days']) && $data['trigger_days'] < 0) {
            $errors['trigger_days'] = 'Trigger days must be a positive number';
        }

        // Validate third party emails format
        if (!empty($data['thirdparty_emails'])) {
            $emails = explode(',', $data['thirdparty_emails']);
            foreach ($emails as $email) {
                $email = trim($email);
                if (!empty($email) && !validate_email($email)) {
                    $errors['thirdparty_emails'] = 'Invalid email format. Use comma-separated email addresses.';
                    break;
                }
            }
        }

        // Validate template selection
        if (empty($data['templateid']) || $data['templateid'] == 0) {
            $errors['templateid'] = 'Please select an email template';
        }

        return $errors;
    }
}
