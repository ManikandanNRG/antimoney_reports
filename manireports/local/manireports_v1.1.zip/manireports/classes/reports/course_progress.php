<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Course progress report.
 *
 * @package     local_manireports
 * @copyright   2024 ManiReports
 * @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_manireports\reports;

defined('MOODLE_INTERNAL') || die();

/**
 * Course progress report class.
 */
class course_progress extends base_report {

    /**
     * Get report name.
     *
     * @return string
     */
    public function get_name() {
        return get_string('courseprogress', 'local_manireports');
    }

    /**
     * Get report description.
     *
     * @return string
     */
    public function get_description() {
        return get_string('courseprogress_desc', 'local_manireports');
    }

    /**
     * Get SQL query for course progress report.
     *
     * @return string SQL query
     */
    protected function get_sql() {
        $sql = "SELECT CONCAT(u.id, '_', c.id) AS uniqueid,
                       u.id AS userid,
                       u.firstname,
                       u.lastname,
                       u.email,
                       c.id AS courseid,
                       c.fullname AS coursename,
                       COUNT(DISTINCT cm.id) AS total_activities,
                       COUNT(DISTINCT cmc.id) AS completed_activities,
                       CASE 
                           WHEN COUNT(DISTINCT cm.id) > 0 
                           THEN ROUND((COUNT(DISTINCT cmc.id) * 100.0 / COUNT(DISTINCT cm.id)), 2)
                           ELSE 0 
                       END AS progress_percentage,
                       cc.timecompleted
                  FROM {user} u
                  JOIN {user_enrolments} ue ON ue.userid = u.id
                  JOIN {enrol} e ON e.id = ue.enrolid
                  JOIN {course} c ON c.id = e.courseid
             LEFT JOIN {course_modules} cm ON cm.course = c.id 
                   AND cm.completion > 0
                   AND cm.deletioninprogress = 0
             LEFT JOIN {course_modules_completion} cmc ON cmc.coursemoduleid = cm.id 
                   AND cmc.userid = u.id
                   AND cmc.completionstate > 0
             LEFT JOIN {course_completions} cc ON cc.course = c.id 
                   AND cc.userid = u.id
                 WHERE u.deleted = 0
                   AND u.suspended = 0
                   AND ue.status = 0
                   AND c.id > 1";

        // Add course filter if provided.
        if (!empty($this->params['courseid'])) {
            $sql .= " AND c.id = :courseid";
        }

        // Add user filter if provided.
        if (!empty($this->params['userid'])) {
            $sql .= " AND u.id = :userid";
        }

        $sql .= " GROUP BY u.id, u.firstname, u.lastname, u.email, c.id, c.fullname, cc.timecompleted
                  ORDER BY c.fullname ASC, u.lastname ASC, u.firstname ASC";

        return $sql;
    }

    /**
     * Get column definitions.
     *
     * @return array
     */
    protected function get_columns() {
        return array(
            'firstname' => get_string('firstname', 'moodle'),
            'lastname' => get_string('lastname', 'moodle'),
            'email' => get_string('email', 'moodle'),
            'coursename' => get_string('course', 'local_manireports'),
            'total_activities' => get_string('totalactivities', 'local_manireports'),
            'completed_activities' => get_string('completedactivities', 'local_manireports'),
            'progress_percentage' => get_string('progresspercentage', 'local_manireports'),
            'timecompleted' => get_string('timecompleted', 'local_manireports')
        );
    }

    /**
     * Get filter definitions.
     *
     * @return array
     */
    public function get_filters() {
        $filters = parent::get_filters();

        $filters['courseid'] = array(
            'type' => 'course',
            'label' => get_string('course', 'local_manireports')
        );

        $filters['userid'] = array(
            'type' => 'user',
            'label' => get_string('user', 'local_manireports')
        );

        return $filters;
    }

    /**
     * Format row for display.
     *
     * @param object $row
     * @return object
     */
    public function format_row($row) {
        // Call parent formatting first (handles common timestamps).
        $row = parent::format_row($row);
        // No additional formatting needed - parent handles timecompleted.
        return $row;
    }
}
