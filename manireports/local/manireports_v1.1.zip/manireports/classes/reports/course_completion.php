<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Course completion report.
 *
 * @package     local_manireports
 * @copyright   2024 ManiReports
 * @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_manireports\reports;

defined('MOODLE_INTERNAL') || die();

/**
 * Course completion report class.
 */
class course_completion extends base_report {

    /**
     * Get report name.
     *
     * @return string
     */
    public function get_name() {
        return get_string('coursecompletion', 'local_manireports');
    }

    /**
     * Get report description.
     *
     * @return string
     */
    public function get_description() {
        return get_string('coursecompletion_desc', 'local_manireports');
    }

    /**
     * Get SQL query for course completion report.
     *
     * @return string SQL query
     */
    protected function get_sql() {
        $sql = "SELECT c.id,
                       c.fullname AS coursename,
                       c.shortname,
                       COUNT(DISTINCT ue.userid) AS enrolled,
                       COUNT(DISTINCT cc.userid) AS completed,
                       CASE 
                           WHEN COUNT(DISTINCT ue.userid) > 0 
                           THEN ROUND((COUNT(DISTINCT cc.userid) * 100.0 / COUNT(DISTINCT ue.userid)), 2)
                           ELSE 0 
                       END AS completion_percentage
                  FROM {course} c
                  JOIN {enrol} e ON e.courseid = c.id
                  JOIN {user_enrolments} ue ON ue.enrolid = e.id
                  JOIN {user} u ON u.id = ue.userid
             LEFT JOIN {course_completions} cc ON cc.course = c.id 
                   AND cc.userid = ue.userid 
                   AND cc.timecompleted IS NOT NULL
                 WHERE c.id > 1
                   AND u.deleted = 0
                   AND ue.status = 0";

        // Add date range filter if provided.
        if (!empty($this->params['datefrom'])) {
            $sql .= " AND ue.timecreated >= :datefrom";
        }
        if (!empty($this->params['dateto'])) {
            $sql .= " AND ue.timecreated <= :dateto";
        }

        // Add course filter if provided.
        if (!empty($this->params['courseid'])) {
            $sql .= " AND c.id = :courseid";
        }

        $sql .= " GROUP BY c.id, c.fullname, c.shortname
                  ORDER BY c.fullname ASC";

        return $sql;
    }

    /**
     * Get column definitions.
     *
     * @return array
     */
    protected function get_columns() {
        return array(
            'coursename' => get_string('course', 'local_manireports'),
            'shortname' => get_string('shortname', 'local_manireports'),
            'enrolled' => get_string('enrolled', 'local_manireports'),
            'completed' => get_string('completed', 'moodle'),
            'completion_percentage' => get_string('completionpercentage', 'local_manireports')
        );
    }

    /**
     * Get default parameters.
     *
     * @return array
     */
    public function get_default_params() {
        return array(
            'datefrom' => strtotime('-30 days'),
            'dateto' => time()
        );
    }

    /**
     * Get filter definitions.
     *
     * @return array
     */
    public function get_filters() {
        $filters = parent::get_filters();

        $filters['datefrom'] = array(
            'type' => 'date',
            'label' => get_string('datefrom', 'local_manireports')
        );

        $filters['dateto'] = array(
            'type' => 'date',
            'label' => get_string('dateto', 'local_manireports')
        );

        $filters['courseid'] = array(
            'type' => 'course',
            'label' => get_string('course', 'local_manireports')
        );

        return $filters;
    }

    /**
     * Get chart configuration.
     *
     * @return array
     */
    public function get_chart_config() {
        return array(
            'type' => 'bar',
            'title' => get_string('coursecompletion', 'local_manireports'),
            'xaxis' => 'coursename',
            'yaxis' => 'completion_percentage',
            'label' => get_string('completionpercentage', 'local_manireports')
        );
    }
}
