<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Dashboard renderer for ManiReports.
 *
 * @package     local_manireports
 * @copyright   2024 ManiReports
 * @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_manireports\output;

defined('MOODLE_INTERNAL') || die();

/**
 * Dashboard renderer class.
 */
class dashboard_renderer extends \plugin_renderer_base {

    /**
     * Render dashboard based on user role.
     *
     * @param int $userid User ID
     * @return string HTML output
     */
    public function render_dashboard($userid) {
        global $OUTPUT;

        $context = \context_system::instance();

        // Determine which dashboard to show based on capabilities.
        if (has_capability('local/manireports:viewadmindashboard', $context, $userid)) {
            return $this->render_admin_dashboard($userid);
        } else if (has_capability('local/manireports:viewmanagerdashboard', $context, $userid)) {
            return $this->render_manager_dashboard($userid);
        } else if (has_capability('local/manireports:viewteacherdashboard', $context, $userid)) {
            return $this->render_teacher_dashboard($userid);
        } else if (has_capability('local/manireports:viewstudentdashboard', $context, $userid)) {
            return $this->render_student_dashboard($userid);
        }

        return $OUTPUT->notification(get_string('error:nopermission', 'local_manireports'), 'error');
    }

    /**
     * Render admin dashboard.
     *
     * @param int $userid User ID
     * @return string HTML output
     */
    protected function render_admin_dashboard($userid) {
        $data = array(
            'title' => get_string('admindashboard', 'local_manireports'),
            'widgets' => $this->get_admin_widgets($userid),
            'companies' => $this->get_companies_data(),
            'courseusage' => $this->get_course_usage_data(),
            'inactiveusers' => $this->get_inactive_users_list(),
            'hasisomad' => $this->is_iomad_installed()
        );

        return $this->render_from_template('local_manireports/dashboard_admin', $data);
    }

    /**
     * Render manager dashboard.
     *
     * @param int $userid User ID
     * @return string HTML output
     */
    protected function render_manager_dashboard($userid) {
        $data = array(
            'title' => get_string('managerdashboard', 'local_manireports'),
            'widgets' => $this->get_manager_widgets($userid)
        );

        return $this->render_from_template('local_manireports/dashboard_manager', $data);
    }

    /**
     * Render teacher dashboard.
     *
     * @param int $userid User ID
     * @return string HTML output
     */
    protected function render_teacher_dashboard($userid) {
        $data = array(
            'title' => get_string('teacherdashboard', 'local_manireports'),
            'widgets' => $this->get_teacher_widgets($userid)
        );

        return $this->render_from_template('local_manireports/dashboard_teacher', $data);
    }

    /**
     * Render student dashboard.
     *
     * @param int $userid User ID
     * @return string HTML output
     */
    protected function render_student_dashboard($userid) {
        $data = array(
            'title' => get_string('studentdashboard', 'local_manireports'),
            'widgets' => $this->get_student_widgets($userid)
        );

        return $this->render_from_template('local_manireports/dashboard_student', $data);
    }

    /**
     * Get widgets for admin dashboard.
     *
     * @param int $userid User ID
     * @return array Array of widget data
     */
    protected function get_admin_widgets($userid) {
        global $DB;

        $widgets = array();

        // Total users widget.
        $totalusers = $DB->count_records('user', array('deleted' => 0, 'suspended' => 0));
        $widgets[] = array(
            'type' => 'kpi',
            'title' => get_string('totalusers', 'local_manireports'),
            'value' => $totalusers,
            'icon' => 'users'
        );

        // Total courses widget.
        $totalcourses = $DB->count_records_select('course', 'id > 1');
        $widgets[] = array(
            'type' => 'kpi',
            'title' => get_string('totalcourses', 'local_manireports'),
            'value' => $totalcourses,
            'icon' => 'book'
        );

        // Total enrollments widget.
        $totalenrolments = $DB->count_records('user_enrolments', array('status' => 0));
        $widgets[] = array(
            'type' => 'kpi',
            'title' => get_string('totalenrolments', 'local_manireports'),
            'value' => $totalenrolments,
            'icon' => 'graduation-cap'
        );

        // Active users (last 30 days).
        $thirtydays = time() - (30 * 24 * 60 * 60);
        $activeusers = $DB->count_records_select('user', 
            'deleted = 0 AND suspended = 0 AND lastaccess > :lastaccess',
            array('lastaccess' => $thirtydays)
        );
        $widgets[] = array(
            'type' => 'kpi',
            'title' => get_string('activeusers30days', 'local_manireports'),
            'value' => $activeusers,
            'icon' => 'user-check'
        );

        // Inactive users (no login in 30 days).
        $inactiveusers = $DB->count_records_select('user',
            'deleted = 0 AND suspended = 0 AND (lastaccess < :lastaccess OR lastaccess = 0)',
            array('lastaccess' => $thirtydays)
        );
        $widgets[] = array(
            'type' => 'kpi',
            'title' => get_string('inactiveusers30days', 'local_manireports'),
            'value' => $inactiveusers,
            'icon' => 'user-times',
            'alert' => $inactiveusers > 0
        );

        // Course completions (last 30 days).
        $completions = $DB->count_records_select('course_completions',
            'timecompleted > :timecompleted',
            array('timecompleted' => $thirtydays)
        );
        $widgets[] = array(
            'type' => 'kpi',
            'title' => get_string('completions30days', 'local_manireports'),
            'value' => $completions,
            'icon' => 'trophy'
        );

        return $widgets;
    }

    /**
     * Get widgets for manager dashboard.
     *
     * @param int $userid User ID
     * @return array Array of widget data
     */
    protected function get_manager_widgets($userid) {
        // Similar to admin but filtered by company.
        return $this->get_admin_widgets($userid);
    }

    /**
     * Get widgets for teacher dashboard.
     *
     * @param int $userid User ID
     * @return array Array of widget data
     */
    protected function get_teacher_widgets($userid) {
        global $DB;

        $widgets = array();

        // Get courses where user is teacher.
        $sql = "SELECT COUNT(DISTINCT c.id)
                  FROM {course} c
                  JOIN {context} ctx ON ctx.instanceid = c.id AND ctx.contextlevel = 50
                  JOIN {role_assignments} ra ON ra.contextid = ctx.id
                  JOIN {role} r ON r.id = ra.roleid
                 WHERE ra.userid = :userid
                   AND r.archetype IN ('editingteacher', 'teacher')";
        
        $mycourses = $DB->count_records_sql($sql, array('userid' => $userid));

        $widgets[] = array(
            'type' => 'kpi',
            'title' => get_string('mycourses', 'local_manireports'),
            'value' => $mycourses,
            'icon' => 'book'
        );

        return $widgets;
    }

    /**
     * Get widgets for student dashboard.
     *
     * @param int $userid User ID
     * @return array Array of widget data
     */
    protected function get_student_widgets($userid) {
        global $DB;

        $widgets = array();

        // Get enrolled courses.
        $enrolledcourses = $DB->count_records_sql(
            "SELECT COUNT(DISTINCT c.id)
               FROM {course} c
               JOIN {enrol} e ON e.courseid = c.id
               JOIN {user_enrolments} ue ON ue.enrolid = e.id
              WHERE ue.userid = :userid
                AND ue.status = 0
                AND c.id > 1",
            array('userid' => $userid)
        );

        $widgets[] = array(
            'type' => 'kpi',
            'title' => get_string('enrolledcourses', 'local_manireports'),
            'value' => $enrolledcourses,
            'icon' => 'book'
        );

        // Get completed courses.
        $completedcourses = $DB->count_records('course_completions', 
            array('userid' => $userid, 'timecompleted' => array('>', 0))
        );

        $widgets[] = array(
            'type' => 'kpi',
            'title' => get_string('completedcourses', 'local_manireports'),
            'value' => $completedcourses,
            'icon' => 'check-circle'
        );

        return $widgets;
    }

    /**
     * Render a single widget.
     *
     * @param array $widget Widget data
     * @return string HTML output
     */
    public function render_widget($widget) {
        $template = 'local_manireports/widget_' . $widget['type'];
        return $this->render_from_template($template, $widget);
    }

    /**
     * Check if IOMAD is installed.
     *
     * @return bool True if IOMAD is installed
     */
    protected function is_iomad_installed() {
        global $CFG;
        return file_exists($CFG->dirroot . '/local/iomad/lib.php');
    }

    /**
     * Get companies data for IOMAD installations.
     *
     * @return array Array of company data
     */
    protected function get_companies_data() {
        global $DB;

        if (!$this->is_iomad_installed()) {
            return array();
        }

        $companies = array();

        try {
            $companyrecords = $DB->get_records('company', null, 'name ASC');

            foreach ($companyrecords as $company) {
                // Count users in company.
                $usercount = $DB->count_records('company_users', array('companyid' => $company->id));

                // Count courses in company.
                $coursecount = $DB->count_records('company_course', array('companyid' => $company->id));

                $companies[] = array(
                    'id' => $company->id,
                    'name' => format_string($company->name),
                    'shortname' => format_string($company->shortname),
                    'usercount' => $usercount,
                    'coursecount' => $coursecount
                );
            }
        } catch (\dml_exception $e) {
            // IOMAD tables might not exist, return empty array.
            debugging('IOMAD tables not found: ' . $e->getMessage(), DEBUG_DEVELOPER);
        }

        return $companies;
    }

    /**
     * Get course usage data for heatmap.
     *
     * @return array Array of course usage data
     */
    protected function get_course_usage_data() {
        global $DB;

        $courses = array();

        // Get top 10 most accessed courses in last 30 days.
        $thirtydays = time() - (30 * 24 * 60 * 60);

        $sql = "SELECT c.id, c.fullname, c.shortname, COUNT(DISTINCT l.userid) as usercount,
                       COUNT(l.id) as accesscount
                  FROM {course} c
                  JOIN {logstore_standard_log} l ON l.courseid = c.id
                 WHERE c.id > 1
                   AND l.timecreated > :timecreated
              GROUP BY c.id, c.fullname, c.shortname
              ORDER BY accesscount DESC
                 LIMIT 10";

        try {
            $records = $DB->get_records_sql($sql, array('timecreated' => $thirtydays));

            foreach ($records as $record) {
                $courses[] = array(
                    'id' => $record->id,
                    'fullname' => format_string($record->fullname),
                    'shortname' => format_string($record->shortname),
                    'usercount' => $record->usercount,
                    'accesscount' => $record->accesscount
                );
            }
        } catch (\dml_exception $e) {
            debugging('Error fetching course usage: ' . $e->getMessage(), DEBUG_DEVELOPER);
        }

        return $courses;
    }

    /**
     * Get list of inactive users.
     *
     * @return array Array of inactive user data
     */
    protected function get_inactive_users_list() {
        global $DB;

        $users = array();

        // Get users who haven't logged in for 30 days.
        $thirtydays = time() - (30 * 24 * 60 * 60);

        $sql = "SELECT u.id, u.firstname, u.lastname, u.email, u.lastaccess
                  FROM {user} u
                 WHERE u.deleted = 0
                   AND u.suspended = 0
                   AND (u.lastaccess < :lastaccess OR u.lastaccess = 0)
                   AND u.id > 2
              ORDER BY u.lastaccess ASC
                 LIMIT 20";

        try {
            $records = $DB->get_records_sql($sql, array('lastaccess' => $thirtydays));

            foreach ($records as $record) {
                $users[] = array(
                    'id' => $record->id,
                    'fullname' => fullname($record),
                    'email' => $record->email,
                    'lastaccess' => $record->lastaccess > 0 ? 
                        userdate($record->lastaccess, get_string('strftimedatetime', 'langconfig')) : 
                        get_string('never'),
                    'daysinactive' => $record->lastaccess > 0 ? 
                        floor((time() - $record->lastaccess) / (24 * 60 * 60)) : 
                        get_string('never')
                );
            }
        } catch (\dml_exception $e) {
            debugging('Error fetching inactive users: ' . $e->getMessage(), DEBUG_DEVELOPER);
        }

        return $users;
    }
}
