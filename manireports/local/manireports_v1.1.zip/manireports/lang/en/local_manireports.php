<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Plugin strings are defined here.
 *
 * @package     local_manireports
 * @copyright   2024 ManiReports
 * @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

// Plugin name.
$string['pluginname'] = 'ManiReports';

// Capabilities.
$string['manireports:viewadmindashboard'] = 'View admin dashboard';
$string['manireports:viewmanagerdashboard'] = 'View company manager dashboard';
$string['manireports:viewteacherdashboard'] = 'View teacher dashboard';
$string['manireports:viewstudentdashboard'] = 'View student dashboard';
$string['manireports:managereports'] = 'Manage reports';
$string['manireports:schedule'] = 'Schedule reports';
$string['manireports:customreports'] = 'Create custom reports';

// General settings.
$string['generalsettings'] = 'General Settings';
$string['enabletimetracking'] = 'Enable time tracking';
$string['enabletimetracking_desc'] = 'Enable JavaScript-based time tracking with heartbeat mechanism';
$string['heartbeatinterval'] = 'Heartbeat interval';
$string['heartbeatinterval_desc'] = 'Time in seconds between heartbeat signals (20-30 recommended)';
$string['sessiontimeout'] = 'Session timeout';
$string['sessiontimeout_desc'] = 'Time in minutes before a session is considered inactive';

// Cache settings.
$string['cachesettings'] = 'Cache Settings';
$string['cachettl_dashboard'] = 'Dashboard cache TTL';
$string['cachettl_dashboard_desc'] = 'Time to live for dashboard widget cache in seconds (default: 3600 = 1 hour)';
$string['cachettl_trends'] = 'Trend reports cache TTL';
$string['cachettl_trends_desc'] = 'Time to live for trend report cache in seconds (default: 21600 = 6 hours)';
$string['cachettl_historical'] = 'Historical reports cache TTL';
$string['cachettl_historical_desc'] = 'Time to live for historical report cache in seconds (default: 86400 = 24 hours)';

// Report settings.
$string['reportsettings'] = 'Report Execution Settings';
$string['querytimeout'] = 'Query timeout';
$string['querytimeout_desc'] = 'Maximum execution time for report queries in seconds';
$string['maxconcurrentreports'] = 'Maximum concurrent reports';
$string['maxconcurrentreports_desc'] = 'Maximum number of reports that can execute simultaneously';

// Data retention settings.
$string['retentionsettings'] = 'Data Retention Settings';
$string['auditlogretention'] = 'Audit log retention';
$string['auditlogretention_desc'] = 'Number of days to retain audit log entries';
$string['reportrunretention'] = 'Report run retention';
$string['reportrunretention_desc'] = 'Number of days to retain report run history';

// At-risk learner settings.
$string['atrisksettings'] = 'At-Risk Learner Detection';
$string['atrisk_mintime'] = 'Minimum time spent (hours)';
$string['atrisk_mintime_desc'] = 'Minimum hours spent in course to avoid at-risk flag';
$string['atrisk_maxdays'] = 'Maximum days since login';
$string['atrisk_maxdays_desc'] = 'Maximum days since last login before at-risk flag';
$string['atrisk_mincompletion'] = 'Minimum completion percentage';
$string['atrisk_mincompletion_desc'] = 'Minimum completion percentage to avoid at-risk flag';

// Dashboard strings.
$string['dashboard'] = 'Dashboard';
$string['admindashboard'] = 'Admin Dashboard';
$string['managerdashboard'] = 'Manager Dashboard';
$string['teacherdashboard'] = 'Teacher Dashboard';
$string['studentdashboard'] = 'Student Dashboard';

// Report strings.
$string['reports'] = 'Reports';
$string['customreports'] = 'Custom Reports';
$string['customreport'] = 'Custom Report';
$string['schedules'] = 'Scheduled Reports';
$string['createcustomreport'] = 'Create Custom Report';
$string['nocustomreports'] = 'No custom reports found. Create one to get started.';
$string['reportname'] = 'Report Name';
$string['reporttype'] = 'Report Type';
$string['sqlreport'] = 'SQL Report';
$string['sqlquery'] = 'SQL Query';
$string['sqlquery_help'] = 'Enter a SELECT query using Moodle table notation {tablename}. Only whitelisted tables are allowed. Use named parameters like :paramname for dynamic values.';
$string['allowedtables'] = 'Allowed Tables';
$string['savereport'] = 'Save Report';
$string['reportcreated'] = 'Report created successfully';
$string['reportupdated'] = 'Report updated successfully';
$string['reportdeleted'] = 'Report deleted successfully';
$string['confirmdelete'] = 'Are you sure you want to delete this report? This action cannot be undone.';
$string['auditlog'] = 'Audit Log';
$string['auditlogs'] = 'Audit Logs';
$string['action'] = 'Action';
$string['objecttype'] = 'Object Type';
$string['objectid'] = 'Object ID';
$string['details'] = 'Details';
$string['ipaddress'] = 'IP Address';
$string['noauditlogs'] = 'No audit logs found';
$string['viewauditlog'] = 'View Audit Log';
$string['attempts'] = 'Attempts';
$string['score'] = 'Score';
$string['lastaccess'] = 'Last Access';
$string['createschedule'] = 'Create Schedule';
$string['editschedule'] = 'Edit Schedule';
$string['deleteschedule'] = 'Delete Schedule';
$string['schedulename'] = 'Schedule Name';
$string['frequency'] = 'Frequency';
$string['daily'] = 'Daily';
$string['weekly'] = 'Weekly';
$string['monthly'] = 'Monthly';
$string['recipients'] = 'Recipients';
$string['addrecipient'] = 'Add Recipient';
$string['enabled'] = 'Enabled';
$string['disabled'] = 'Disabled';
$string['lastrun'] = 'Last Run';
$string['nextrun'] = 'Next Run';
$string['status'] = 'Status';
$string['actions'] = 'Actions';
$string['noschedules'] = 'No schedules found';
$string['schedulecreated'] = 'Schedule created successfully';
$string['scheduleupdated'] = 'Schedule updated successfully';
$string['scheduledeleted'] = 'Schedule deleted successfully';
$string['recipients_help'] = 'Enter one email address per line. These recipients will receive the scheduled report.';
$string['coursecompletion'] = 'Course Completion';
$string['coursecompletion_desc'] = 'View course completion statistics with enrollment and completion percentages';
$string['courseprogress'] = 'Course Progress';
$string['courseprogress_desc'] = 'View individual user progress across courses with activity completion tracking';
$string['scormsummary'] = 'SCORM Summary';
$string['scormsummary_desc'] = 'View SCORM activity analytics including attempts, completion, and scores';
$string['userengagement'] = 'User Engagement';
$string['userengagement_desc'] = 'View user engagement metrics including time spent and active days';
$string['quizattempts'] = 'Quiz Attempts';
$string['quizattempts_desc'] = 'View quiz attempt statistics including scores and completion rates';

// Report column strings.
$string['completionpercentage'] = 'Completion %';
$string['progresspercentage'] = 'Progress %';
$string['totalactivities'] = 'Total Activities';
$string['completedactivities'] = 'Completed Activities';
$string['scormname'] = 'SCORM Activity';
$string['scormactivity'] = 'SCORM Activity';
$string['totaltime'] = 'Total Time';
$string['timespent7days'] = 'Time (7 days)';
$string['timespent30days'] = 'Time (30 days)';
$string['activedays7'] = 'Active Days (7)';
$string['activedays30'] = 'Active Days (30)';
$string['quizname'] = 'Quiz';
$string['totalattempts'] = 'Total Attempts';
$string['finishedattempts'] = 'Finished Attempts';
$string['averagescore'] = 'Average Score';
$string['bestscore'] = 'Best Score';
$string['lastattempt'] = 'Last Attempt';
$string['datefrom'] = 'Date From';
$string['dateto'] = 'Date To';
$string['shortname'] = 'Short Name';
$string['enrolled'] = 'Enrolled';
$string['timecompleted'] = 'Time Completed';
$string['quiz'] = 'Quiz';
$string['totalrecords'] = 'Total records: {$a}';

// Common strings.
$string['export'] = 'Export';
$string['exportcsv'] = 'Export CSV';
$string['exportxlsx'] = 'Export Excel';
$string['exportpdf'] = 'Export PDF';
$string['filters'] = 'Filters';
$string['daterange'] = 'Date Range';
$string['company'] = 'Company';
$string['course'] = 'Course';
$string['user'] = 'User';
$string['loading'] = 'Loading...';
$string['nodata'] = 'No data available';
$string['executiontime'] = 'Execution time';
$string['cachedhit'] = 'Cached result';
$string['cachemiss'] = 'Fresh data';
$string['totalusers'] = 'Total Users';
$string['totalcourses'] = 'Total Courses';
$string['totalenrolments'] = 'Total Enrolments';
$string['mycourses'] = 'My Courses';
$string['enrolledcourses'] = 'Enrolled Courses';
$string['completedcourses'] = 'Completed Courses';
$string['activeusers30days'] = 'Active Users (30 days)';
$string['inactiveusers30days'] = 'Inactive Users (30 days)';
$string['completions30days'] = 'Completions (30 days)';
$string['companies'] = 'Companies';
$string['nocompanies'] = 'No companies found';
$string['users'] = 'Users';
$string['courses'] = 'Courses';
$string['courseusage'] = 'Course Usage (Top 10)';
$string['courseusagedesc'] = 'Most accessed courses in the last 30 days';
$string['activeusers'] = 'Active Users';
$string['totalaccesses'] = 'Total Accesses';
$string['nocourseusage'] = 'No course usage data available';
$string['inactiveusers'] = 'Inactive Users';
$string['inactiveusersdesc'] = 'Users who have not logged in for 30 days or more';
$string['daysinactive'] = 'Days Inactive';
$string['noinactiveusers'] = 'No inactive users found';

// Task strings.
$string['task_timeaggregation'] = 'Time tracking aggregation';
$string['task_cachebuilder'] = 'Cache builder';
$string['task_reportscheduler'] = 'Report scheduler';
$string['task_scormsummary'] = 'SCORM summary aggregation';
$string['task_cleanupolddata'] = 'Cleanup old data';

// Error messages.
$string['error:nopermission'] = 'You do not have permission to access this page';
$string['error:invalidparameters'] = 'Invalid parameters provided';
$string['error:reportnotfound'] = 'Report not found';
$string['error:databaseerror'] = 'Database error occurred: {$a}';
$string['error:unexpectederror'] = 'An unexpected error occurred';
$string['error:unsupportedformat'] = 'Unsupported export format: {$a}';
$string['error:schedulenotfound'] = 'Schedule not found';
$string['error:invalidfrequency'] = 'Invalid frequency: {$a}';
$string['error:invalidcharttype'] = 'Invalid chart type: {$a}';
$string['error:invalidsql'] = 'Invalid SQL query. Please check for blocked keywords, non-whitelisted tables, or syntax errors.';
$string['error:querytimeout'] = 'Query execution exceeded timeout limit of {$a} seconds';
$string['error:reportnamerequired'] = 'Report name is required';
$string['error:sqlqueryrequired'] = 'SQL query is required for SQL-type reports';

// Privacy.
$string['privacy:metadata:manireports_time_sessions'] = 'Stores user time tracking session data';
$string['privacy:metadata:manireports_time_sessions:userid'] = 'User ID';
$string['privacy:metadata:manireports_time_sessions:courseid'] = 'Course ID';
$string['privacy:metadata:manireports_time_sessions:sessionstart'] = 'Session start timestamp';
$string['privacy:metadata:manireports_time_sessions:lastupdated'] = 'Last update timestamp';
$string['privacy:metadata:manireports_time_sessions:duration'] = 'Session duration in seconds';

$string['privacy:metadata:manireports_time_daily'] = 'Stores aggregated daily time tracking data';
$string['privacy:metadata:manireports_time_daily:userid'] = 'User ID';
$string['privacy:metadata:manireports_time_daily:courseid'] = 'Course ID';
$string['privacy:metadata:manireports_time_daily:date'] = 'Date';
$string['privacy:metadata:manireports_time_daily:duration'] = 'Total duration in seconds';

$string['privacy:metadata:manireports_audit_logs'] = 'Stores audit trail of user actions';
$string['privacy:metadata:manireports_audit_logs:userid'] = 'User ID';
$string['privacy:metadata:manireports_audit_logs:action'] = 'Action performed';
$string['privacy:metadata:manireports_audit_logs:objecttype'] = 'Object type';
$string['privacy:metadata:manireports_audit_logs:objectid'] = 'Object ID';
$string['privacy:metadata:manireports_audit_logs:details'] = 'Action details';
$string['privacy:metadata:manireports_audit_logs:timecreated'] = 'Time created';

// Dashboard builder strings.
$string['confirmunsavedchanges'] = 'You have unsaved changes. Are you sure you want to leave?';
$string['confirmremovewidget'] = 'Are you sure you want to remove this widget?';
$string['unsavedchanges'] = 'You have unsaved changes.';
$string['dashboardnamerequired'] = 'Dashboard name is required.';
$string['dashboardsaved'] = 'Dashboard saved successfully.';
$string['addwidget'] = 'Add Widget';
$string['editwidget'] = 'Edit Widget';
$string['widgettitle'] = 'Widget Title';
$string['widgettype'] = 'Widget Type';
$string['datasource'] = 'Data Source';
$string['widgetwidth'] = 'Width (%)';
$string['widgetheight'] = 'Height (px)';
$string['kpiwidget'] = 'KPI Widget';
$string['linechartwidget'] = 'Line Chart';
$string['barchartwidget'] = 'Bar Chart';
$string['piechartwidget'] = 'Pie Chart';
$string['tablewidget'] = 'Table Widget';

// GUI Report Builder
$string['guireportbuilder'] = 'GUI Report Builder';
$string['selecttables'] = 'Select Tables';
$string['selecttable'] = 'Select a table...';
$string['addtable'] = 'Add Table';
$string['selectcolumns'] = 'Select Columns';
$string['joins'] = 'Table Joins';
$string['addjoin'] = 'Add Join';
$string['filterlogic'] = 'Filter Logic';
$string['grouping'] = 'Grouping';
$string['addgroupby'] = 'Add Group By';
$string['sorting'] = 'Sorting';
$string['addorderby'] = 'Add Order By';
$string['sqlpreview'] = 'SQL Preview';
$string['savereport'] = 'Save Report';
$string['reportname'] = 'Report Name';
$string['invalidconfig'] = 'Invalid configuration: {$a}';
$string['invalidtable'] = 'Invalid table: {$a}';
$string['invalidreporttype'] = 'Invalid report type';
$string['reportsaved'] = 'Report saved successfully';
$string['none'] = 'None';

// Table labels
$string['table_user'] = 'Users';
$string['table_course'] = 'Courses';
$string['table_course_categories'] = 'Course Categories';
$string['table_enrol'] = 'Enrolment Methods';
$string['table_user_enrolments'] = 'User Enrolments';
$string['table_course_completions'] = 'Course Completions';
$string['table_course_modules'] = 'Course Modules';
$string['table_course_modules_completion'] = 'Module Completions';
$string['table_grade_grades'] = 'Grades';
$string['table_grade_items'] = 'Grade Items';
$string['table_quiz'] = 'Quizzes';
$string['table_quiz_attempts'] = 'Quiz Attempts';
$string['table_scorm'] = 'SCORM Activities';
$string['table_scorm_scoes_track'] = 'SCORM Tracking';
$string['table_logstore_standard_log'] = 'Activity Logs';
$string['table_role_assignments'] = 'Role Assignments';
$string['table_context'] = 'Contexts';

// Column labels (fallback - will use column name if not defined)
$string['column_user_id'] = 'User ID';
$string['column_user_username'] = 'Username';
$string['column_user_firstname'] = 'First Name';
$string['column_user_lastname'] = 'Last Name';
$string['column_user_email'] = 'Email';
$string['column_course_id'] = 'Course ID';
$string['column_course_fullname'] = 'Course Name';
$string['column_course_shortname'] = 'Short Name';
$string['column_course_timecreated'] = 'Created Time';

// Schedule form strings.
$string['reportcategory'] = 'Report Category';
$string['prebuiltreports'] = 'Prebuilt Reports';
$string['prebuiltreport'] = 'Prebuilt Report';
$string['selectreport'] = 'Select a report...';
$string['configjsonrequired'] = 'GUI configuration is required';
$string['invalidconfig'] = 'Invalid report configuration';
$string['reportsaved'] = 'Report saved successfully';

// GUI Report Builder strings.
$string['guireportbuilder'] = 'GUI Report Builder';
$string['selecttables'] = 'Select Tables';
$string['selecttable'] = 'Select a table...';
$string['addtable'] = 'Add Table';
$string['selectcolumns'] = 'Select Columns';
$string['joins'] = 'Table Joins';
$string['addjoin'] = 'Add Join';
$string['filters'] = 'Filters';
$string['addfilter'] = 'Add Filter';
$string['filterlogic'] = 'Filter Logic';
$string['grouping'] = 'Grouping';
$string['addgroupby'] = 'Add Group By';
$string['sorting'] = 'Sorting';
$string['addorderby'] = 'Add Order By';
$string['sqlpreview'] = 'SQL Preview';

// Table labels (fallback).
$string['table_user'] = 'Users';
$string['table_course'] = 'Courses';
$string['table_course_categories'] = 'Course Categories';
$string['table_enrol'] = 'Enrolment Methods';
$string['table_user_enrolments'] = 'User Enrolments';
$string['table_course_completions'] = 'Course Completions';
$string['table_course_modules'] = 'Course Modules';
$string['table_course_modules_completion'] = 'Module Completions';
$string['table_grade_grades'] = 'Grades';
$string['table_grade_items'] = 'Grade Items';
$string['table_quiz'] = 'Quizzes';
$string['table_quiz_attempts'] = 'Quiz Attempts';
$string['table_scorm'] = 'SCORM Activities';
$string['table_scorm_scoes_track'] = 'SCORM Tracking';
$string['table_logstore_standard_log'] = 'Activity Logs';
$string['table_role_assignments'] = 'Role Assignments';
$string['table_context'] = 'Contexts';

// Column labels (fallback - will use column name if not defined).
$string['column_user_id'] = 'User ID';
$string['column_user_username'] = 'Username';
$string['column_user_firstname'] = 'First Name';
$string['column_user_lastname'] = 'Last Name';
$string['column_user_email'] = 'Email';
$string['column_course_id'] = 'Course ID';
$string['column_course_fullname'] = 'Course Name';
$string['column_course_shortname'] = 'Short Name';

// Drill-down strings.
$string['appliedfilters'] = 'Applied Filters';
$string['clearfilters'] = 'Clear Filters';
$string['drilldown'] = 'Drill Down';
$string['drilldownview'] = 'Drill-Down View';
$string['backtoparent'] = 'Back to Parent View';
$string['exportdrilldown'] = 'Export Drill-Down Data';
$string['nodrilldowndata'] = 'No drill-down data available';
$string['drilldownfailed'] = 'Failed to load drill-down view';
