<?php
namespace local_manireports\api;

defined('MOODLE_INTERNAL') || die();

/**
 * Class CloudJobManager
 *
 * Manages the lifecycle of cloud offload jobs: creation, submission, and status updates.
 *
 * @package     local_manireports
 * @copyright   2024 ManiReports
 */
class CloudJobManager {

    /**
     * Creates a new cloud job in the database.
     *
     * @param string $type The type of job (e.g., 'csv_import', 'license_allocation').
     * @param array $recipients Array of recipients data. Each item must have 'email'.
     * @param int $company_id The IOMAD company ID.
     * @return int The ID of the created job.
     * @throws \dml_exception
     */
    public function create_job(string $type, array $recipients, int $company_id): int {
        global $DB;

        $job = new \stdClass();
        $job->type = $type;
        $job->status = 'pending';
        $job->email_count = count($recipients);
        $job->company_id = $company_id;
            $recipients = $DB->get_records('manireports_cloud_recipients', ['job_id' => $job_id]);
            
            // Prepare payload
            $payload = [
                'job_id' => $job_id,
                'type' => $job->type,
                'recipients' => array_values($recipients) // Ensure array is indexed
            ];

            $message_id = $connector->submit_job($payload);

            if ($message_id) {
                $this->update_job_status($job_id, 'queued');
                return true;
            } else {
                $this->update_job_status($job_id, 'failed');
                return false;
            }

        } catch (\Exception $e) {
            $this->log_error($job_id, "Submission failed: " . $e->getMessage());
            $this->update_job_status($job_id, 'failed');
            return false;
        }
    }

    /**
     * Updates the status of a job.
     *
     * @param int $job_id
     * @param string $status
     * @return void
     */
    public function update_job_status(int $job_id, string $status): void {
        global $DB;
        $update = new \stdClass();
        $update->id = $job_id;
        $update->status = $status;
        
        if ($status === 'processing') {
            $update->started_at = time();
        } elseif (in_array($status, ['completed', 'failed', 'partial_failure'])) {
            $update->completed_at = time();
        }

        $DB->update_record('manireports_cloud_jobs', $update);
    }

    /**
     * Handles the callback from the cloud worker.
     *
     * @param int $job_id
     * @param array $data Callback data (status, sent_count, failed_count, errors)
     * @return void
     */
    public function handle_callback(int $job_id, array $data): void {
        global $DB;

        $job = $DB->get_record('manireports_cloud_jobs', ['id' => $job_id], '*', MUST_EXIST);

        $update = new \stdClass();
        $update->id = $job_id;
        $update->status = $data['status'];
        $update->emails_sent = $data['emails_sent'] ?? 0;
        $update->emails_failed = $data['emails_failed'] ?? 0;
        $update->completed_at = time();
        
        if (!empty($data['errors'])) {
            $update->error_log = json_encode($data['errors']);
        }

        $DB->update_record('manireports_cloud_jobs', $update);

        // Update individual recipients if detailed status provided
        // (This depends on the granularity of the callback from the worker)
    }

    /**
     * Logs an error for a job.
     *
     * @param int $job_id
     * @param string $message
     * @return void
     */
    private function log_error(int $job_id, string $message): void {
        global $DB;
        $job = $DB->get_record('manireports_cloud_jobs', ['id' => $job_id]);
        if ($job) {
            $current_log = $job->error_log ? $job->error_log . "\n" : "";
            $new_log = $current_log . "[" . date('Y-m-d H:i:s') . "] " . $message;
            $DB->set_field('manireports_cloud_jobs', 'error_log', $new_log, ['id' => $job_id]);
        }
    }
}
