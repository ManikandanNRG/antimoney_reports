<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Core report builder API for generating reports from SQL queries.
 *
 * @package     local_manireports
 * @copyright   2024 ManiReports
 * @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_manireports\api;

defined('MOODLE_INTERNAL') || die();

/**
 * Report builder class for executing and managing reports.
 */
class report_builder {

    /**
     * Whitelist of allowed Moodle tables for custom SQL reports.
     *
     * @var array
     */
    private static $allowed_tables = array(
        'user', 'course', 'course_categories', 'course_completions',
        'course_modules', 'course_modules_completion', 'enrol', 'user_enrolments',
        'role', 'role_assignments', 'context', 'grade_grades', 'grade_items',
        'quiz', 'quiz_attempts', 'quiz_grades', 'scorm', 'scorm_scoes_track',
        'assign', 'assign_submission', 'assign_grades', 'forum', 'forum_posts',
        'forum_discussions', 'logstore_standard_log', 'company', 'company_users',
        'company_course', 'manireports_time_daily', 'manireports_scorm_summary',
        'manireports_cache_summary'
    );

    /**
     * Blocked SQL keywords that are not allowed in custom reports.
     *
     * @var array
     */
    private static $blocked_keywords = array(
        'DROP', 'CREATE', 'ALTER', 'TRUNCATE', 'INSERT', 'UPDATE', 'DELETE',
        'GRANT', 'REVOKE', 'EXEC', 'EXECUTE', 'CALL', 'DECLARE', 'SET'
    );

    /**
     * Execute a report by ID with parameters.
     *
     * @param int $reportid Report ID from manireports_customreports table
     * @param array $params Parameters to bind to the query
     * @param int $userid User ID executing the report (for IOMAD filtering)
     * @param int $page Page number for pagination (0-based)
     * @param int $perpage Records per page
     * @return array Array containing 'data' (result rows), 'columns' (column names), 'total' (total count)
     * @throws \moodle_exception
     */
    public function execute_report($reportid, $params = array(), $userid = 0, $page = 0, $perpage = 25) {
        global $DB, $USER;

        if ($userid === 0) {
            $userid = $USER->id;
        }

        // Get report definition.
        $report = $DB->get_record('manireports_customreports', array('id' => $reportid), '*', MUST_EXIST);

        // Validate SQL.
        if (!$this->validate_sql($report->sqlquery)) {
            throw new \moodle_exception('invalidsql', 'local_manireports');
        }

        // Apply IOMAD company filter if applicable.
        $sql = $report->sqlquery;
        if (iomad_filter::is_iomad_installed()) {
            $companyid = isset($params['companyid']) ? $params['companyid'] : null;
            $sql = iomad_filter::apply_company_filter($sql, $userid, 'u', $companyid);
        }

        // Apply dynamic filters.
        $sql = $this->apply_filters($sql, $params);

        // Get total count for pagination.
        $countsql = $this->get_count_sql($sql);
        $total = $DB->count_records_sql($countsql, $params);

        // Execute query with pagination.
        $timeout = get_config('local_manireports', 'querytimeout') ?: 60;
        $DB->set_debug(false); // Disable debug for performance.
        
        try {
            $results = $DB->get_records_sql($sql, $params, $page * $perpage, $perpage);
        } catch (\dml_exception $e) {
            debugging('Report execution error: ' . $e->getMessage(), DEBUG_DEVELOPER);
            throw new \moodle_exception('databaseerror', 'local_manireports');
        }

        // Extract column names from first result.
        $columns = array();
        if (!empty($results)) {
            $firstrow = reset($results);
            $columns = array_keys((array)$firstrow);
        }

        return array(
            'data' => array_values($results),
            'columns' => $columns,
            'total' => $total,
            'page' => $page,
            'perpage' => $perpage
        );
    }

    /**
     * Validate SQL query for security.
     *
     * @param string $sql SQL query to validate
     * @return bool True if valid, false otherwise
     */
    public function validate_sql($sql) {
        if (empty($sql)) {
            return false;
        }

        // Convert to uppercase for checking.
        $sqlup = strtoupper($sql);

        // Check for blocked keywords.
        foreach (self::$blocked_keywords as $keyword) {
            if (strpos($sqlup, $keyword) !== false) {
                debugging('Blocked keyword found: ' . $keyword, DEBUG_DEVELOPER);
                return false;
            }
        }

        // Must start with SELECT.
        if (strpos(trim($sqlup), 'SELECT') !== 0) {
            debugging('Query must start with SELECT', DEBUG_DEVELOPER);
            return false;
        }

        // Validate table names against whitelist.
        if (!$this->validate_tables($sql)) {
            debugging('Query contains non-whitelisted tables', DEBUG_DEVELOPER);
            return false;
        }

        // Check for balanced parameter placeholders.
        if (!$this->validate_parameters($sql)) {
            debugging('Invalid parameter placeholders', DEBUG_DEVELOPER);
            return false;
        }

        return true;
    }

    /**
     * Validate that all tables in query are whitelisted.
     *
     * @param string $sql SQL query
     * @return bool True if all tables are whitelisted
     */
    private function validate_tables($sql) {
        global $CFG;

        // Extract table names from FROM and JOIN clauses.
        $pattern = '/(?:FROM|JOIN)\s+\{([a-z_]+)\}/i';
        preg_match_all($pattern, $sql, $matches);

        if (empty($matches[1])) {
            return false;
        }

        $tables = array_unique($matches[1]);

        foreach ($tables as $table) {
            if (!in_array($table, self::$allowed_tables)) {
                debugging('Table not whitelisted: ' . $table, DEBUG_DEVELOPER);
                return false;
            }
        }

        return true;
    }

    /**
     * Validate parameter placeholders in SQL.
     *
     * @param string $sql SQL query
     * @return bool True if parameters are valid
     */
    private function validate_parameters($sql) {
        // Check for named parameters (:paramname).
        preg_match_all('/:([a-z0-9_]+)/i', $sql, $matches);
        
        // Basic validation - just ensure they follow naming convention.
        if (!empty($matches[1])) {
            foreach ($matches[1] as $param) {
                if (!preg_match('/^[a-z0-9_]+$/i', $param)) {
                    return false;
                }
            }
        }

        return true;
    }

    /**
     * Apply dynamic filters to SQL query.
     *
     * @param string $sql Original SQL query
     * @param array $filters Filter parameters
     * @return string Modified SQL query
     */
    public function apply_filters($sql, $filters) {
        // Filters are applied via parameter binding, not SQL modification.
        // This method is a placeholder for future filter logic.
        return $sql;
    }

    /**
     * Generate count SQL from original query.
     *
     * @param string $sql Original SQL query
     * @return string Count SQL query
     */
    private function get_count_sql($sql) {
        // Simple approach: wrap query in COUNT.
        // Remove ORDER BY clause for count query.
        $countsql = preg_replace('/ORDER BY .+$/i', '', $sql);
        return "SELECT COUNT(*) FROM ($countsql) countquery";
    }

    /**
     * Save a new custom report.
     *
     * @param object $report Report object with name, description, type, sqlquery, configjson
     * @param int $userid User ID creating the report
     * @return int New report ID
     * @throws \moodle_exception
     */
    public function save_report($report, $userid) {
        global $DB;

        // Validate required fields.
        if (empty($report->name)) {
            throw new \moodle_exception('reportnamerequired', 'local_manireports');
        }

        if ($report->type === 'sql' && empty($report->sqlquery)) {
            throw new \moodle_exception('sqlqueryrequired', 'local_manireports');
        }

        // Validate SQL if type is sql.
        if ($report->type === 'sql' && !$this->validate_sql($report->sqlquery)) {
            throw new \moodle_exception('invalidsql', 'local_manireports');
        }

        $now = time();
        $record = new \stdClass();
        $record->name = $report->name;
        $record->description = $report->description ?? '';
        $record->type = $report->type ?? 'sql';
        $record->sqlquery = $report->sqlquery ?? null;
        $record->configjson = $report->configjson ?? null;
        $record->createdby = $userid;
        $record->timecreated = $now;
        $record->timemodified = $now;

        $reportid = $DB->insert_record('manireports_customreports', $record);

        // Log audit trail.
        $this->log_audit($userid, 'create', 'report', $reportid, $report->name);

        return $reportid;
    }

    /**
     * Update an existing custom report.
     *
     * @param int $reportid Report ID
     * @param object $report Report object with fields to update
     * @param int $userid User ID updating the report
     * @return bool True on success
     * @throws \moodle_exception
     */
    public function update_report($reportid, $report, $userid) {
        global $DB;

        $existing = $DB->get_record('manireports_customreports', array('id' => $reportid), '*', MUST_EXIST);

        // Validate SQL if being updated.
        if (isset($report->sqlquery) && !empty($report->sqlquery)) {
            if (!$this->validate_sql($report->sqlquery)) {
                throw new \moodle_exception('invalidsql', 'local_manireports');
            }
        }

        $record = new \stdClass();
        $record->id = $reportid;
        $record->name = $report->name ?? $existing->name;
        $record->description = $report->description ?? $existing->description;
        $record->sqlquery = $report->sqlquery ?? $existing->sqlquery;
        $record->configjson = $report->configjson ?? $existing->configjson;
        $record->timemodified = time();

        $DB->update_record('manireports_customreports', $record);

        // Log audit trail.
        $this->log_audit($userid, 'update', 'report', $reportid, $record->name);

        return true;
    }

    /**
     * Delete a custom report.
     *
     * @param int $reportid Report ID
     * @param int $userid User ID deleting the report
     * @return bool True on success
     * @throws \moodle_exception
     */
    public function delete_report($reportid, $userid) {
        global $DB;

        $report = $DB->get_record('manireports_customreports', array('id' => $reportid), '*', MUST_EXIST);

        // Delete associated schedules.
        $DB->delete_records('manireports_schedules', array('reportid' => $reportid));

        // Delete the report.
        $DB->delete_records('manireports_customreports', array('id' => $reportid));

        // Log audit trail.
        $this->log_audit($userid, 'delete', 'report', $reportid, $report->name);

        return true;
    }

    /**
     * Get list of custom reports with filtering.
     *
     * @param int $userid User ID (for permission filtering)
     * @param string $type Filter by type (sql, gui, or null for all)
     * @return array Array of report records
     */
    public function get_reports($userid, $type = null) {
        global $DB;

        $params = array();
        $where = '1=1';

        if ($type !== null) {
            $where .= ' AND type = :type';
            $params['type'] = $type;
        }

        // Site admins see all reports, others see only their own.
        if (!is_siteadmin($userid)) {
            $where .= ' AND createdby = :userid';
            $params['userid'] = $userid;
        }

        return $DB->get_records_select('manireports_customreports', $where, $params, 'name ASC');
    }

    /**
     * Log audit trail for report operations.
     *
     * @param int $userid User ID
     * @param string $action Action performed
     * @param string $objecttype Object type
     * @param int $objectid Object ID
     * @param string $details Additional details
     */
    private function log_audit($userid, $action, $objecttype, $objectid, $details) {
        global $DB;

        $record = new \stdClass();
        $record->userid = $userid;
        $record->action = $action;
        $record->objecttype = $objecttype;
        $record->objectid = $objectid;
        $record->details = $details;
        $record->timecreated = time();

        $DB->insert_record('manireports_audit_logs', $record);
    }
}
