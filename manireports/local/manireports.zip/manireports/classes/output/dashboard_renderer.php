<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Dashboard renderer for ManiReports.
 *
 * @package     local_manireports
 * @copyright   2024 ManiReports
 * @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_manireports\output;

defined('MOODLE_INTERNAL') || die();

/**
 * Dashboard renderer class.
 */
class dashboard_renderer extends \plugin_renderer_base {

    /**
     * Render dashboard based on user role.
     *
     * @param int $userid User ID
     * @return string HTML output
     */
    public function render_dashboard($userid) {
        global $OUTPUT;

        $context = \context_system::instance();

        // Determine which dashboard to show based on capabilities.
        if (has_capability('local/manireports:viewadmindashboard', $context, $userid)) {
            return $this->render_admin_dashboard($userid);
        } else if (has_capability('local/manireports:viewmanagerdashboard', $context, $userid)) {
            return $this->render_manager_dashboard($userid);
        } else if (has_capability('local/manireports:viewteacherdashboard', $context, $userid)) {
            return $this->render_teacher_dashboard($userid);
        } else if (has_capability('local/manireports:viewstudentdashboard', $context, $userid)) {
            return $this->render_student_dashboard($userid);
        }

        return $OUTPUT->notification(get_string('error:nopermission', 'local_manireports'), 'error');
    }

    /**
     * Render admin dashboard.
     *
     * @param int $userid User ID
     * @return string HTML output
     */
    protected function render_admin_dashboard($userid) {
        $data = array(
            'title' => get_string('admindashboard', 'local_manireports'),
            'widgets' => $this->get_admin_widgets($userid)
        );

        return $this->render_from_template('local_manireports/dashboard_admin', $data);
    }

    /**
     * Render manager dashboard.
     *
     * @param int $userid User ID
     * @return string HTML output
     */
    protected function render_manager_dashboard($userid) {
        $data = array(
            'title' => get_string('managerdashboard', 'local_manireports'),
            'widgets' => $this->get_manager_widgets($userid)
        );

        return $this->render_from_template('local_manireports/dashboard_manager', $data);
    }

    /**
     * Render teacher dashboard.
     *
     * @param int $userid User ID
     * @return string HTML output
     */
    protected function render_teacher_dashboard($userid) {
        $data = array(
            'title' => get_string('teacherdashboard', 'local_manireports'),
            'widgets' => $this->get_teacher_widgets($userid)
        );

        return $this->render_from_template('local_manireports/dashboard_teacher', $data);
    }

    /**
     * Render student dashboard.
     *
     * @param int $userid User ID
     * @return string HTML output
     */
    protected function render_student_dashboard($userid) {
        $data = array(
            'title' => get_string('studentdashboard', 'local_manireports'),
            'widgets' => $this->get_student_widgets($userid)
        );

        return $this->render_from_template('local_manireports/dashboard_student', $data);
    }

    /**
     * Get widgets for admin dashboard.
     *
     * @param int $userid User ID
     * @return array Array of widget data
     */
    protected function get_admin_widgets($userid) {
        global $DB;

        $widgets = array();

        // Total users widget.
        $totalusers = $DB->count_records('user', array('deleted' => 0, 'suspended' => 0));
        $widgets[] = array(
            'type' => 'kpi',
            'title' => get_string('totalusers', 'local_manireports'),
            'value' => $totalusers,
            'icon' => 'users'
        );

        // Total courses widget.
        $totalcourses = $DB->count_records_select('course', 'id > 1');
        $widgets[] = array(
            'type' => 'kpi',
            'title' => get_string('totalcourses', 'local_manireports'),
            'value' => $totalcourses,
            'icon' => 'book'
        );

        // Total enrollments widget.
        $totalenrolments = $DB->count_records('user_enrolments', array('status' => 0));
        $widgets[] = array(
            'type' => 'kpi',
            'title' => get_string('totalenrolments', 'local_manireports'),
            'value' => $totalenrolments,
            'icon' => 'graduation-cap'
        );

        return $widgets;
    }

    /**
     * Get widgets for manager dashboard.
     *
     * @param int $userid User ID
     * @return array Array of widget data
     */
    protected function get_manager_widgets($userid) {
        // Similar to admin but filtered by company.
        return $this->get_admin_widgets($userid);
    }

    /**
     * Get widgets for teacher dashboard.
     *
     * @param int $userid User ID
     * @return array Array of widget data
     */
    protected function get_teacher_widgets($userid) {
        global $DB;

        $widgets = array();

        // Get courses where user is teacher.
        $sql = "SELECT COUNT(DISTINCT c.id)
                  FROM {course} c
                  JOIN {context} ctx ON ctx.instanceid = c.id AND ctx.contextlevel = 50
                  JOIN {role_assignments} ra ON ra.contextid = ctx.id
                  JOIN {role} r ON r.id = ra.roleid
                 WHERE ra.userid = :userid
                   AND r.archetype IN ('editingteacher', 'teacher')";
        
        $mycourses = $DB->count_records_sql($sql, array('userid' => $userid));

        $widgets[] = array(
            'type' => 'kpi',
            'title' => get_string('mycourses', 'local_manireports'),
            'value' => $mycourses,
            'icon' => 'book'
        );

        return $widgets;
    }

    /**
     * Get widgets for student dashboard.
     *
     * @param int $userid User ID
     * @return array Array of widget data
     */
    protected function get_student_widgets($userid) {
        global $DB;

        $widgets = array();

        // Get enrolled courses.
        $enrolledcourses = $DB->count_records_sql(
            "SELECT COUNT(DISTINCT c.id)
               FROM {course} c
               JOIN {enrol} e ON e.courseid = c.id
               JOIN {user_enrolments} ue ON ue.enrolid = e.id
              WHERE ue.userid = :userid
                AND ue.status = 0
                AND c.id > 1",
            array('userid' => $userid)
        );

        $widgets[] = array(
            'type' => 'kpi',
            'title' => get_string('enrolledcourses', 'local_manireports'),
            'value' => $enrolledcourses,
            'icon' => 'book'
        );

        // Get completed courses.
        $completedcourses = $DB->count_records('course_completions', 
            array('userid' => $userid, 'timecompleted' => array('>', 0))
        );

        $widgets[] = array(
            'type' => 'kpi',
            'title' => get_string('completedcourses', 'local_manireports'),
            'value' => $completedcourses,
            'icon' => 'check-circle'
        );

        return $widgets;
    }

    /**
     * Render a single widget.
     *
     * @param array $widget Widget data
     * @return string HTML output
     */
    public function render_widget($widget) {
        $template = 'local_manireports/widget_' . $widget['type'];
        return $this->render_from_template($template, $widget);
    }
}
