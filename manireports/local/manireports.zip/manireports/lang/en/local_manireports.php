<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Plugin strings are defined here.
 *
 * @package     local_manireports
 * @copyright   2024 ManiReports
 * @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

// Plugin name.
$string['pluginname'] = 'ManiReports';

// Capabilities.
$string['manireports:viewadmindashboard'] = 'View admin dashboard';
$string['manireports:viewmanagerdashboard'] = 'View company manager dashboard';
$string['manireports:viewteacherdashboard'] = 'View teacher dashboard';
$string['manireports:viewstudentdashboard'] = 'View student dashboard';
$string['manireports:managereports'] = 'Manage reports';
$string['manireports:schedule'] = 'Schedule reports';
$string['manireports:customreports'] = 'Create custom reports';

// General settings.
$string['generalsettings'] = 'General Settings';
$string['enabletimetracking'] = 'Enable time tracking';
$string['enabletimetracking_desc'] = 'Enable JavaScript-based time tracking with heartbeat mechanism';
$string['heartbeatinterval'] = 'Heartbeat interval';
$string['heartbeatinterval_desc'] = 'Time in seconds between heartbeat signals (20-30 recommended)';
$string['sessiontimeout'] = 'Session timeout';
$string['sessiontimeout_desc'] = 'Time in minutes before a session is considered inactive';

// Cache settings.
$string['cachesettings'] = 'Cache Settings';
$string['cachettl_dashboard'] = 'Dashboard cache TTL';
$string['cachettl_dashboard_desc'] = 'Time to live for dashboard widget cache in seconds (default: 3600 = 1 hour)';
$string['cachettl_trends'] = 'Trend reports cache TTL';
$string['cachettl_trends_desc'] = 'Time to live for trend report cache in seconds (default: 21600 = 6 hours)';
$string['cachettl_historical'] = 'Historical reports cache TTL';
$string['cachettl_historical_desc'] = 'Time to live for historical report cache in seconds (default: 86400 = 24 hours)';

// Report settings.
$string['reportsettings'] = 'Report Execution Settings';
$string['querytimeout'] = 'Query timeout';
$string['querytimeout_desc'] = 'Maximum execution time for report queries in seconds';
$string['maxconcurrentreports'] = 'Maximum concurrent reports';
$string['maxconcurrentreports_desc'] = 'Maximum number of reports that can execute simultaneously';

// Data retention settings.
$string['retentionsettings'] = 'Data Retention Settings';
$string['auditlogretention'] = 'Audit log retention';
$string['auditlogretention_desc'] = 'Number of days to retain audit log entries';
$string['reportrunretention'] = 'Report run retention';
$string['reportrunretention_desc'] = 'Number of days to retain report run history';

// At-risk learner settings.
$string['atrisksettings'] = 'At-Risk Learner Detection';
$string['atrisk_mintime'] = 'Minimum time spent (hours)';
$string['atrisk_mintime_desc'] = 'Minimum hours spent in course to avoid at-risk flag';
$string['atrisk_maxdays'] = 'Maximum days since login';
$string['atrisk_maxdays_desc'] = 'Maximum days since last login before at-risk flag';
$string['atrisk_mincompletion'] = 'Minimum completion percentage';
$string['atrisk_mincompletion_desc'] = 'Minimum completion percentage to avoid at-risk flag';

// Dashboard strings.
$string['dashboard'] = 'Dashboard';
$string['admindashboard'] = 'Admin Dashboard';
$string['managerdashboard'] = 'Manager Dashboard';
$string['teacherdashboard'] = 'Teacher Dashboard';
$string['studentdashboard'] = 'Student Dashboard';

// Report strings.
$string['reports'] = 'Reports';
$string['customreports'] = 'Custom Reports';
$string['schedules'] = 'Scheduled Reports';
$string['auditlog'] = 'Audit Log';
$string['coursecompletion'] = 'Course Completion';
$string['coursecompletion_desc'] = 'View course completion statistics with enrollment and completion percentages';
$string['courseprogress'] = 'Course Progress';
$string['courseprogress_desc'] = 'View individual user progress across courses with activity completion tracking';
$string['scormsummary'] = 'SCORM Summary';
$string['scormsummary_desc'] = 'View SCORM activity analytics including attempts, completion, and scores';
$string['userengagement'] = 'User Engagement';
$string['userengagement_desc'] = 'View user engagement metrics including time spent and active days';
$string['quizattempts'] = 'Quiz Attempts';
$string['quizattempts_desc'] = 'View quiz attempt statistics including scores and completion rates';

// Report column strings.
$string['completionpercentage'] = 'Completion %';
$string['progresspercentage'] = 'Progress %';
$string['totalactivities'] = 'Total Activities';
$string['completedactivities'] = 'Completed Activities';
$string['scormname'] = 'SCORM Activity';
$string['scormactivity'] = 'SCORM Activity';
$string['totaltime'] = 'Total Time';
$string['timespent7days'] = 'Time (7 days)';
$string['timespent30days'] = 'Time (30 days)';
$string['activedays7'] = 'Active Days (7)';
$string['activedays30'] = 'Active Days (30)';
$string['quizname'] = 'Quiz';
$string['totalattempts'] = 'Total Attempts';
$string['finishedattempts'] = 'Finished Attempts';
$string['averagescore'] = 'Average Score';
$string['bestscore'] = 'Best Score';
$string['lastattempt'] = 'Last Attempt';
$string['datefrom'] = 'Date From';
$string['dateto'] = 'Date To';
$string['shortname'] = 'Short Name';

// Common strings.
$string['export'] = 'Export';
$string['exportcsv'] = 'Export CSV';
$string['exportxlsx'] = 'Export Excel';
$string['exportpdf'] = 'Export PDF';
$string['filters'] = 'Filters';
$string['daterange'] = 'Date Range';
$string['company'] = 'Company';
$string['course'] = 'Course';
$string['user'] = 'User';
$string['loading'] = 'Loading...';
$string['nodata'] = 'No data available';
$string['totalusers'] = 'Total Users';
$string['totalcourses'] = 'Total Courses';
$string['totalenrolments'] = 'Total Enrolments';
$string['mycourses'] = 'My Courses';
$string['enrolledcourses'] = 'Enrolled Courses';
$string['completedcourses'] = 'Completed Courses';

// Task strings.
$string['task_timeaggregation'] = 'Time tracking aggregation';
$string['task_cachebuilder'] = 'Cache builder';
$string['task_reportscheduler'] = 'Report scheduler';
$string['task_scormsummary'] = 'SCORM summary aggregation';
$string['task_cleanupolddata'] = 'Cleanup old data';

// Error messages.
$string['error:nopermission'] = 'You do not have permission to access this page';
$string['error:invalidparameters'] = 'Invalid parameters provided';
$string['error:reportnotfound'] = 'Report not found';
$string['error:databaseerror'] = 'Database error occurred';
$string['error:unexpectederror'] = 'An unexpected error occurred';

// Privacy.
$string['privacy:metadata:manireports_time_sessions'] = 'Stores user time tracking session data';
$string['privacy:metadata:manireports_time_sessions:userid'] = 'User ID';
$string['privacy:metadata:manireports_time_sessions:courseid'] = 'Course ID';
$string['privacy:metadata:manireports_time_sessions:sessionstart'] = 'Session start timestamp';
$string['privacy:metadata:manireports_time_sessions:lastupdated'] = 'Last update timestamp';
$string['privacy:metadata:manireports_time_sessions:duration'] = 'Session duration in seconds';

$string['privacy:metadata:manireports_time_daily'] = 'Stores aggregated daily time tracking data';
$string['privacy:metadata:manireports_time_daily:userid'] = 'User ID';
$string['privacy:metadata:manireports_time_daily:courseid'] = 'Course ID';
$string['privacy:metadata:manireports_time_daily:date'] = 'Date';
$string['privacy:metadata:manireports_time_daily:duration'] = 'Total duration in seconds';

$string['privacy:metadata:manireports_audit_logs'] = 'Stores audit trail of user actions';
$string['privacy:metadata:manireports_audit_logs:userid'] = 'User ID';
$string['privacy:metadata:manireports_audit_logs:action'] = 'Action performed';
$string['privacy:metadata:manireports_audit_logs:objecttype'] = 'Object type';
$string['privacy:metadata:manireports_audit_logs:objectid'] = 'Object ID';
$string['privacy:metadata:manireports_audit_logs:details'] = 'Action details';
$string['privacy:metadata:manireports_audit_logs:timecreated'] = 'Time created';
