<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Report view page for ManiReports.
 *
 * @package     local_manireports
 * @copyright   2024 ManiReports
 * @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(__DIR__ . '/../../../config.php');

require_login();

$context = context_system::instance();
$PAGE->set_context($context);

// Get parameters.
$reporttype = required_param('report', PARAM_ALPHA);
$page = optional_param('page', 0, PARAM_INT);
$perpage = optional_param('perpage', 25, PARAM_INT);

// Get filter parameters.
$courseid = optional_param('courseid', 0, PARAM_INT);
$userid = optional_param('userid', 0, PARAM_INT);
$datefrom = optional_param('datefrom', 0, PARAM_INT);
$dateto = optional_param('dateto', 0, PARAM_INT);
$companyid = optional_param('companyid', 0, PARAM_INT);

// Build parameters array.
$params = array();
if ($courseid) {
    $params['courseid'] = $courseid;
}
if ($userid) {
    $params['userid'] = $userid;
}
if ($datefrom) {
    $params['datefrom'] = $datefrom;
}
if ($dateto) {
    $params['dateto'] = $dateto;
}
if ($companyid) {
    $params['companyid'] = $companyid;
}

// Check capability.
$hascapability = has_capability('local/manireports:viewadmindashboard', $context) ||
                 has_capability('local/manireports:viewmanagerdashboard', $context) ||
                 has_capability('local/manireports:viewteacherdashboard', $context) ||
                 has_capability('local/manireports:viewstudentdashboard', $context);

if (!$hascapability) {
    throw new moodle_exception('error:nopermission', 'local_manireports');
}

// Create report instance.
$reportclass = "\\local_manireports\\reports\\{$reporttype}";
if (!class_exists($reportclass)) {
    // Try to help with debugging.
    debugging("Report class not found: {$reportclass}. Available report files: " . 
        implode(', ', glob(__DIR__ . '/../classes/reports/*.php')), DEBUG_DEVELOPER);
    throw new moodle_exception('error:reportnotfound', 'local_manireports', '', $reportclass);
}

$report = new $reportclass($USER->id, $params);

// Check permission for this specific report.
if (!$report->has_permission($USER->id)) {
    throw new moodle_exception('error:nopermission', 'local_manireports');
}

// Execute report.
try {
    $result = $report->execute($page, $perpage);
} catch (Exception $e) {
    throw new moodle_exception('error:unexpectederror', 'local_manireports', '', $e->getMessage());
}

// Set up the page.
$PAGE->set_url(new moodle_url('/local/manireports/ui/report_view.php', array('report' => $reporttype)));
$PAGE->set_title($report->get_name());
$PAGE->set_heading($report->get_name());
$PAGE->set_pagelayout('standard');

// Output header.
echo $OUTPUT->header();

// Display report title and description.
echo html_writer::tag('h2', $report->get_name());
echo html_writer::tag('p', $report->get_description(), array('class' => 'lead'));

// Display filters if available.
$filters = $report->get_filters();
if (!empty($filters)) {
    echo html_writer::start_div('manireports-filters card mb-3');
    echo html_writer::start_div('card-body');
    echo html_writer::tag('h5', get_string('filters', 'local_manireports'), array('class' => 'card-title'));
    
    echo html_writer::start_tag('form', array('method' => 'get', 'action' => $PAGE->url->out(false)));
    echo html_writer::empty_tag('input', array('type' => 'hidden', 'name' => 'report', 'value' => $reporttype));
    
    echo html_writer::start_div('row');
    foreach ($filters as $name => $filter) {
        echo html_writer::start_div('col-md-3 mb-2');
        echo html_writer::tag('label', $filter['label'], array('for' => $name));
        
        if ($filter['type'] === 'select' && isset($filter['options'])) {
            echo html_writer::select($filter['options'], $name, $params[$name] ?? '', array('' => get_string('all')), array('class' => 'form-control'));
        } else if ($filter['type'] === 'date') {
            $value = isset($params[$name]) ? userdate($params[$name], '%Y-%m-%d') : '';
            echo html_writer::empty_tag('input', array('type' => 'date', 'name' => $name, 'value' => $value, 'class' => 'form-control'));
        } else {
            $value = $params[$name] ?? '';
            echo html_writer::empty_tag('input', array('type' => 'text', 'name' => $name, 'value' => $value, 'class' => 'form-control'));
        }
        
        echo html_writer::end_div();
    }
    echo html_writer::end_div();
    
    echo html_writer::tag('button', get_string('apply', 'moodle'), array('type' => 'submit', 'class' => 'btn btn-primary mt-2'));
    echo html_writer::end_tag('form');
    
    echo html_writer::end_div();
    echo html_writer::end_div();
}

// Display results.
if (empty($result['data'])) {
    echo $OUTPUT->notification(get_string('nodata', 'local_manireports'), 'info');
} else {
    // Build table.
    $table = new html_table();
    $table->attributes['class'] = 'generaltable table table-striped';
    
    // Table headers.
    $table->head = array();
    foreach ($result['columns'] as $key => $label) {
        $table->head[] = $label;
    }
    
    // Table rows.
    foreach ($result['data'] as $row) {
        $cells = array();
        foreach (array_keys($result['columns']) as $key) {
            $cells[] = isset($row->$key) ? $row->$key : '-';
        }
        $table->data[] = $cells;
    }
    
    echo html_writer::table($table);
    
    // Pagination.
    if ($result['total'] > $perpage) {
        $baseurl = new moodle_url('/local/manireports/ui/report_view.php', array_merge(array('report' => $reporttype), $params));
        echo $OUTPUT->paging_bar($result['total'], $page, $perpage, $baseurl);
    }
    
    // Display total count.
    echo html_writer::tag('p', get_string('totalrecords', 'moodle', $result['total']), array('class' => 'text-muted mt-2'));
}

// Output footer.
echo $OUTPUT->footer();
